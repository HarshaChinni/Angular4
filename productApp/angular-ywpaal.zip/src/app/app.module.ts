import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';

import { UserService } from './user.service';
import { AuthGuard } from './auth.guard';

const appRoutes : Routes = [
{
  path : '',
  component: LoginComponent
},
{
    path : 'dashboard',
    canActivate: [AuthGuard],
  component: DashboardComponent
}

]

@NgModule({
  imports:[ BrowserModule, FormsModule, RouterModule.forRoot(appRoutes) ],

  declarations: [ AppComponent, HelloComponent, HeaderComponent, FooterComponent, LoginComponent, DashboardComponent ],

  providers: [UserService, AuthGuard],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
